import React from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";

import Home from "pages/Home";
import TelaLogin from "pages/TelaLogin";
import { useAuth } from "hooks/useAuth";

import TelaCadastro from "pages/TelaCadastro";
import CadMedicine from "pages/TelaCadastroRemedio";

export default function Router() {
  const { currentUser, isLoading } = useAuth();

  if (isLoading) return null;

  if (currentUser === null) {
    return (
      <BrowserRouter>
        <Switch>
          <Route exact path="/login" children={<TelaLogin />} />
          <Route exact path="/cadastro" children={<TelaCadastro />} />
          <Redirect path="/" to="/login" />
        </Switch>
      </BrowserRouter>
    );
  }

  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" children={<Home />} />
        <Route exact path="/login" children={<TelaLogin />} />
        <Route exact path="/cadastro" children={<TelaCadastro />} />
        <Route exact path="/registroMedicine" children={<CadMedicine />} />
        <Redirect path="/" to="/" />
      </Switch>
    </BrowserRouter>
  );
}
