import React from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";

import Home from "pages/Home";
import Homep from "pages/Homepage";
import TelaLogin from "pages/TelaLogin";
import { useAuth } from "hooks/useAuth";

import TelaCadastro from "pages/TelaCadastro";
import CadMedicine from "pages/TelaCadastroRemedio";
import TelaUBS from "pages/TelaCadastroUbs";
import PagePerfil from "pages/Perfil"

export default function Router() {
  const { currentUser, isLoading } = useAuth();

  if (isLoading) return null;

  if (currentUser === null) {
    return (
      <BrowserRouter>
        <Switch>
          <Route exact path="/login" children={<TelaLogin />} />
          <Route exact path="/cadastro" children={<TelaCadastro />} />
          <Redirect path="/" to="/login" />
        </Switch>
      </BrowserRouter>
    );
  }

  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" children={<Homep />} />
        <Route exact path="/login" children={<TelaLogin />} />
        <Route exact path="/cadastro" children={<TelaCadastro />} />
        <Route exact path="/registroMedicine" children={<CadMedicine />} />
        <Route exact path="/registroUBS" children={<TelaUBS />} />
        <Route exact path="/perfil" children={<PagePerfil />} />

        <Redirect path="/" to="/" />
      </Switch>
    </BrowserRouter>
  );
}
