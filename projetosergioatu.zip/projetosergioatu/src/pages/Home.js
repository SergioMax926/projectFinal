import React from 'react';
import mapboxgl from '!mapbox-gl'; // eslint-disable-line import/no-webpack-loader-syntax
import MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import '@mapbox/mapbox-gl-geocoder/dist/mapbox-gl-geocoder.css';
import { stores } from 'services/geojson';


 
mapboxgl.accessToken = 'pk.eyJ1Ijoic2VyZ2lvbWF4bHVpcyIsImEiOiJja3MwYTc4ZnIwa2V5Mm9ydzU0ejl3N3IxIn0.daibp8Mw_htYUb95Wf3zPw';
  
export default class App extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
        lng: -59.977458429488586, 
        lat: -3.1341566898425577,
        zoom: 14
        };
        this.mapContainer = React.createRef();
    }
    
    componentDidMount() {
        const { lng, lat, zoom } = this.state;
        const map = new mapboxgl.Map({
        container: this.mapContainer.current,
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [lng, lat],
        zoom: zoom
    });
 
    map.on('move', () => {
        this.setState({
          lng: map.getCenter().lng.toFixed(4),
          lat: map.getCenter().lat.toFixed(4),
          zoom: map.getZoom().toFixed(2)
        });
    }); 


    map.on('load', () => {
        map.addSource('places', {
          type: 'geojson',
          data: stores
        });
      });

      for (const feature of stores.features) {
        const el = document.createElement('div');
        el.className = 'marker';
         
        new mapboxgl.Marker(el)
          .setLngLat(feature.geometry.coordinates)
          .setPopup(
        new mapboxgl.Popup({ offset: 25 }) // add popups
          .setHTML(
          `<h3>${feature.properties.title}</h3><p>${feature.properties.description}</p>`
            )
          )
          .addTo(map);
        }

      map.addControl(
        new MapboxGeocoder({
        accessToken: mapboxgl.accessToken,
        mapboxgl: mapboxgl
        })
    );

      map.addControl(
        new mapboxgl.GeolocateControl({
          positionOptions: {
            enableHighAccuracy: true
          },
            trackUserLocation: true,
            showUserHeading: true
        })
        );

  }

    render() {
      return (
        <div>
          <div ref={this.mapContainer} className="map-container" />
        </div>
      );
  }
  
}
