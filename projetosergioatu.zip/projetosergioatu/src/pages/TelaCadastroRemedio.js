import React, { useState } from "react";
import { css } from "@emotion/css";

import { useHistory } from "react-router-dom";
import Input from "components/Input";
import Button from "components/Button";
import Textarea from "components/Textarea";

import Img from "assets/logoProjetosemBG.png";
import { useMedice } from "hooks/useMedice";

export default function TelaCadastroRemedio() {
  const { createMedicine } = useMedice();

  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [description, setDescription] = useState("");

  const history = useHistory();

  return (
    <div className="TelaInicio">
      <div className="Telainteira">
        <div
          className={css`
            flex-shrink: 1;
            max-width: 500px;
            max-height: 500px;

            margin-right: 30px;
            border-right: 1px solid black;
          `}
        >
          <img
            src={Img}
            className={css`
              width: 45%;
              height: 45%;
            `}
          />
        </div>

        <div id="TelaCad1">
          <h1
            className={css`
              font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
              font-size: 20px;
            `}
          >
            Registro de medicamento
          </h1>

          <Input
            type="text"
            placeholder="Nome do medicamento"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <Input
            type="text"
            placeholder="Código do medicamento"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            maxlength="14"
          />

          <Textarea   class ="medtext"
            type="text"
           
            placeholder="Descrição do medicamento"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxlength="200"
          />

          <div
            className={css`
              display: flex;
              justify-content: space-between;
            `}
          >
            <Button onClick={() => history.push("/login")}>voltar</Button>

            <Button
              onClick={() => {
                createMedicine(name, code, description)
                  .then(() => {
                    history.push("/login");
                  })
                  .catch((e) => {
                    alert("Dados incompletos");
                  });
              }}
            >
              Salvar
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
