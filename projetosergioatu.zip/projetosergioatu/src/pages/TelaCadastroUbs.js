import React, { useState } from "react";
import { css } from "@emotion/css";
import Img from "assets/clinica.png";
import { useHistory } from "react-router-dom";

import { useUbs } from "hooks/useUBS"

import Input from "components/Input";
import Button from "components/Button";
import "../Telas.css";

export default function TelaUBS() {

    const {createUbs} = useUbs();
    

    const history = useHistory();
    const [name, setName] = useState("");
    const [adress, setAdress] = useState("");
  
    return (
      <div
        className={css`
          width: 100vw;
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: #fb4c4c;
        `}
      >
        <div
          className={css`
            display: flex;
            align-items: center;
            justify-content: center;
  
            background-color: white;
  
            border-radius: 16px;
            padding: 24px;
            margin: 100px;
          `}
        >
          <div
            className={css`
              flex-shrink: 1;
              max-width: 400px;
              max-height: 300px;
  
              margin-right: 30px;
              border-right: 1px solid black;
            `}
          >
            <img
              src={Img}
              className={css`
             
                width: 85%;
                height: 85%;
              `}
            />
          </div>
  
          <div
            className={css`
              display: flex;
              flex-direction: column;
              gap: 16px;
              text-align: center;
  
              margin-left: 30px;
              height: 70%;
              width: 70%;
            `}
          >
            <h1
              className={css`
                font-family:Cambria, Cochin, Georgia, Times, "Times New Roman", serif,
                "Lucida Sans", Arial, sans-serif ;
                font-size: 60px;
                
              `}
            >
              Cadastrar UBS
            </h1>
  
            <Input
              type="text"
              placeholder="Nome"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
  
            <Input
              type="text"
              placeholder="Digite o endereço"
              value={adress}
              onChange={(e) => setAdress(e.target.value)}
            />
  
            <div
              className={css`
                display: flex;
                justify-content: space-between;
              `}
            >
              <Button
                onClick={() => {
                    createUbs(name, adress)
                      .then(() => {
                        history.push("/");
                      })
                      .catch((e) => {
                        alert("Dados incompletos");
                      });
                  }}
              >
                Salvar
              </Button>
  
              <Button onClick={() => history.push("/cadastro")}>Cadastrar</Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  