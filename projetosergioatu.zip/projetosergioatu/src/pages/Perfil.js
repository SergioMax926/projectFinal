


export default function PagePerfil(){

    return(
        <div className="TelaInicio">

            <div className="Tela">

            </div>

        </div>

    )
}