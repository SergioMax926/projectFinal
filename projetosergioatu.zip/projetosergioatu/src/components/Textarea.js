import styled from "@emotion/styled";

const Textarea = styled.textarea`
  background-color: #d9d9d9;
  border: 2px solid black;
  border-radius: 8px;
font-family: ;
  font-size: 20px;
  width: 98%;
  height: 100px;
  margin: 0px;
`;

export default Textarea;
