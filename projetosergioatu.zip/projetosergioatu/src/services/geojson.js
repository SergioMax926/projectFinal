export const  geojson = {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [-59.977458429488586, -3.1341566898425577]
        },
        properties: {
          title: 'Mapbox',
          description: 'Fundação Matias Machline'
        }
      },
      {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [ -59.97552723904166, -3.126293473756273]
        },
        properties: {
          title: 'Mapbox',
          description: 'Um cafe aleatorio'
        }
      }
    ]
  }; 