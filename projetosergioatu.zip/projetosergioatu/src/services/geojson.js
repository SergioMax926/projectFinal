export const stores   = {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [-59.977458429488586, -3.1341566898425577]
        },
        properties: {
          title: 'Mapbox',
          description: 'Fundação Matias Machline'
        }
      },
      {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [-59.97630796234336,  -3.1094301525537995]
        },
        properties: {
          title: 'Mapbox',
          description: 'Ulbra'
        }
      }
    ]
  }; 